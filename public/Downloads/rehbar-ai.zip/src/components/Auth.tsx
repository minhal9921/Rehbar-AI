import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, ArrowLeft, Chrome } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface AuthProps {
  onBack: () => void;
}

export default function Auth({ onBack }: AuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();

  const handleLogin = () => {
    // Simulate login and navigate to home
    console.log("Simulating login...");
    navigate("/home");
  };

  return (
    <div className="min-h-screen flex font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Left Column: Form Container */}
      <div className="w-full lg:w-1/2 bg-[#F8F8F6] flex flex-col items-center justify-center p-8 md:p-16 relative">
        {/* Back Button */}
        <button 
          onClick={onBack}
          className="absolute top-8 left-8 flex items-center gap-2 px-4 py-2 bg-[#d97757] text-white rounded-xl text-sm font-medium hover:opacity-90 shadow-sm shadow-[#d97757]/20 transition-all"
        >
          <ArrowLeft size={16} /> Back to home
        </button>

        <div className="w-full max-w-[400px] space-y-8">
          {/* Logo & Headings: Centered outside the container */}
          <div className="space-y-6 text-center">
            <div className="text-xl font-bold tracking-tight font-serif">Rehbar AI</div>
            <div className="space-y-2">
              <AnimatePresence mode="wait">
                <motion.h1 
                  key={isLogin ? 'login' : 'signup'}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  transition={{ duration: 0.2 }}
                  className="text-4xl font-medium tracking-tight font-serif"
                >
                  {isLogin ? "Welcome back" : "Create account"}
                </motion.h1>
              </AnimatePresence>
              <p className="text-black/50 text-sm font-sans italic">
                {isLogin 
                  ? "Continue your career journey." 
                  : "Join students building their future."}
              </p>
            </div>
          </div>

          {/* Form Container */}
          <div className="space-y-6">
            <div className="bg-brand-bg border border-black/20 shadow-[0_0_50px_-12px_rgba(0,0,0,0.1)] rounded-[2.5rem] p-8 md:p-10 space-y-6">
              <div className="space-y-4">
                {/* Social Button */}
                <button 
                  onClick={handleLogin}
                  className="w-full flex items-center justify-center gap-3 px-4 py-2.5 bg-brand-bg border border-black/20 rounded-xl font-medium hover:bg-black/5 transition-all text-base"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.84z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  <span>Continue with Google</span>
                </button>

                {/* Divider */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-black/5"></div>
                  </div>
                  <div className="relative flex justify-center text-[10px] uppercase">
                    <span className="bg-brand-bg px-3 text-black/40 font-sans tracking-widest">or</span>
                  </div>
                </div>

                {/* Form Fields Container */}
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleLogin();
                  }}
                  className="space-y-3"
                >
                  {!isLogin && (
                    <input 
                      type="text" 
                      placeholder="Full Name"
                      className="w-full px-5 py-2.5 rounded-xl border border-black/20 focus:outline-none focus:ring-2 focus:ring-black/5 focus:border-black/20 transition-all bg-white text-base"
                    />
                  )}
                  <input 
                    type="email" 
                    placeholder="Email address"
                    className="w-full px-5 py-2.5 rounded-xl border border-black/20 focus:outline-none focus:ring-2 focus:ring-black/5 focus:border-black/20 transition-all bg-white text-base"
                  />
                  <input 
                    type="password" 
                    placeholder="Password"
                    className="w-full px-5 py-2.5 rounded-xl border border-black/20 focus:outline-none focus:ring-2 focus:ring-black/5 focus:border-black/20 transition-all bg-white text-base"
                  />
                  
                  {/* Submit Button */}
                  <button 
                    type="submit"
                    className="w-full bg-black text-white py-2.5 rounded-xl font-medium hover:bg-black/80 transition-standard shadow-lg shadow-black/5 flex items-center justify-center gap-2 text-base text-center mt-4"
                  >
                    <Mail size={18} />
                    {isLogin ? "Sign in" : "Sign up"}
                  </button>
                </form>
              </div>
            </div>

            {/* Toggle Link: Outside the container card */}
            <div className="text-center">
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-xs font-medium text-black/60 transition-colors"
              >
                {isLogin ? (
                  <>Don't have an account? <span className="hover:underline text-black font-semibold">Sign up</span></>
                ) : (
                  <>Already have an account? <span className="hover:underline text-black font-semibold">Log in</span></>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Image Container */}
      <div className="hidden lg:block lg:w-1/2 relative bg-black overflow-hidden m-4 rounded-[2.5rem]">
        <img 
          src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=2670&auto=format&fit=crop" 
          alt="Modern Education"
          className="absolute inset-0 w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-20 space-y-6">
          <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl w-fit border border-white/20">
            <Chrome size={24} className="text-white" />
          </div>
          <h2 className="text-4xl text-white font-serif font-medium leading-tight">
            "Rehbar AI helped me find a path I never knew existed. It's like having a mentor in my pocket."
          </h2>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gray-500 overflow-hidden border-2 border-white/20">
              <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=100&auto=format&fit=crop" alt="User" />
            </div>
            <div>
              <div className="text-white font-medium">Ahmed Raza</div>
              <div className="text-white/50 text-sm">Computer Science Student</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

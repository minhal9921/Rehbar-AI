import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  PanelLeft, 
  Search, 
  Plus, 
  Settings, 
  Send,
  MessageSquare,
  ChevronRight,
  LogOut
} from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [prompt, setPrompt] = useState("");
  const navigate = useNavigate();

  const recentChats = [
    "Engineering Roadmap",
    "Medical to Tech Pivot",
    "Career in AI Ethics",
    "Study Abroad Guide",
    "Internship Prep 2026"
  ];

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="h-screen flex bg-[#F8F8F6] text-black font-sans overflow-hidden">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 72 }}
        className="h-full border-r border-black/5 bg-white/50 backdrop-blur-sm flex flex-col relative overflow-hidden shrink-0"
      >
        {/* Toggle Button - Fixed position relative to sidebar */}
        <div className="p-4 flex justify-center border-b border-black/5">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-black/5 rounded-xl transition-colors text-black/50"
          >
            <PanelLeft size={!isSidebarOpen ? 24 : 20} className={!isSidebarOpen ? "text-[#d97757]" : ""} />
          </button>
        </div>

        <div className={`flex flex-col h-full overflow-hidden transition-all duration-300 ${isSidebarOpen ? "p-6" : "p-3"}`}>
          <AnimatePresence mode="wait">
            {isSidebarOpen ? (
              <motion.div 
                key="open"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="flex flex-col h-full space-y-8 min-w-[230px]"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold tracking-tight font-serif text-[#d97757]">Rehbar AI</span>
                </div>

                {/* Middle: Actions */}
                <div className="space-y-4 flex-1">
                  <button className="w-full flex items-center gap-3 px-3 py-2 text-sm font-medium text-black/60 hover:bg-black/5 hover:text-black rounded-xl transition-all group font-sans">
                    <Search size={18} className="group-hover:scale-110 transition-transform" />
                    <span>Search</span>
                  </button>
                  
                  <button className="w-full flex items-center gap-3 px-3 py-3 text-sm font-semibold text-white bg-black rounded-xl hover:bg-black/80 transition-all shadow-sm font-sans">
                    <Plus size={18} />
                    <span>New Chat</span>
                  </button>

                  <div className="pt-8 space-y-4">
                    <h3 className="px-3 text-[10px] uppercase tracking-widest text-black/30 font-bold font-sans">Recent Chats</h3>
                    <div className="space-y-1">
                      {recentChats.map((chat, idx) => (
                        <button key={idx} className="w-full flex items-center gap-3 px-3 py-2.5 text-sm text-black/60 hover:bg-black/5 hover:text-black rounded-xl transition-all text-left truncate group font-sans">
                          <MessageSquare size={16} className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
                          <span className="truncate">{chat}</span>
                        </button>
                      ))}
                    </div>
                    <button className="px-3 text-xs font-medium text-black/40 hover:text-black flex items-center gap-1 transition-colors font-sans">
                      View All <ChevronRight size={12} />
                    </button>
                  </div>
                </div>

                {/* Bottom: Settings & User */}
                <div className="pt-4 space-y-2 border-t border-black/5">
                  <button className="w-full flex items-center gap-3 px-3 py-2 text-sm font-medium text-black/60 hover:bg-black/5 hover:text-black rounded-xl transition-all group font-sans">
                    <Settings size={18} />
                    <span>Settings</span>
                  </button>
                  <div className="flex items-center justify-between p-3 bg-black/5 rounded-2xl group font-sans">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#d97757] flex items-center justify-center text-white text-xs font-bold ring-2 ring-white">
                        UR
                      </div>
                      <div className="flex flex-col">
                        <span className="text-sm font-semibold truncate max-w-[120px]">User Name</span>
                        <span className="text-[10px] text-black/40 truncate">Free Plan</span>
                      </div>
                    </div>
                    <button 
                      onClick={handleLogout}
                      className="p-1.5 hover:bg-white rounded-lg transition-colors text-black/30 hover:text-red-500"
                    >
                      <LogOut size={16} />
                    </button>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="closed"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="flex flex-col items-center space-y-6 pt-4"
              >
                <button title="Search" className="p-3 text-black/40 hover:text-black hover:bg-black/5 rounded-xl transition-all">
                  <Search size={22} />
                </button>
                <button title="New Chat" className="p-3 bg-black text-white rounded-xl shadow-md hover:scale-110 active:scale-95 transition-all">
                  <Plus size={22} />
                </button>
                <div className="w-8 h-px bg-black/5" />
                <button title="Recent Chats" className="p-3 text-black/40 hover:text-black hover:bg-black/5 rounded-xl transition-all">
                  <MessageSquare size={22} />
                </button>
                <div className="flex-1" />
                <button title="Settings" className="p-3 text-black/40 hover:text-black hover:bg-black/5 rounded-xl transition-all">
                  <Settings size={22} />
                </button>
                <button 
                  onClick={handleLogout}
                  title="Logout" 
                  className="p-3 text-black/40 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                >
                  <LogOut size={22} />
                </button>
                <button className="w-10 h-10 rounded-full bg-[#d97757] flex items-center justify-center text-white text-xs font-bold ring-2 ring-white shadow-sm mt-2">
                  UR
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.aside>

      {/* Main Content Area */}
      <main className="flex-1 relative flex flex-col">
        {/* Toggle Button removed from here as it's now in the sidebar rail */}

        <div className="flex-1 overflow-y-auto px-6">
          <div className="max-w-3xl mx-auto w-full pt-20 pb-32 space-y-12">
            {/* Greeting */}
            <div className="text-center space-y-4">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl md:text-5xl font-medium tracking-tight font-serif"
              >
                Hello, future leader.
              </motion.h2>
              <p className="text-black/40 font-sans">What's on your mind today? Let's build your roadmap.</p>
            </div>

            {/* Core Prompt Bar */}
            <div className="relative group">
              <div className="bg-white rounded-[2.5rem] border border-black/10 shadow-xl shadow-black/5 overflow-hidden transition-all focus-within:border-black/20 focus-within:shadow-2xl focus-within:shadow-black/10">
                <div className="p-6 md:p-8 space-y-6">
                  {/* Textarea Area */}
                  <div className="relative flex items-start">
                    <textarea 
                      placeholder="What should I do after my high school?"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="w-full bg-transparent border-none focus:ring-0 p-0 text-lg md:text-xl font-sans resize-none min-h-[60px] placeholder:text-black/20"
                      rows={2}
                    />
                    <button className="shrink-0 p-2.5 bg-[#d97757] text-white rounded-full hover:scale-110 active:scale-95 transition-all shadow-md shadow-[#d97757]/30">
                      <Send size={20} />
                    </button>
                  </div>

                  {/* Context Filters */}
                  <div className="pt-6 border-t border-black/5 flex flex-wrap items-center gap-3">
                    <div className="flex flex-col gap-1.5">
                      <span className="text-[10px] uppercase tracking-widest text-black/30 font-bold px-2">Education</span>
                      <select className="bg-black/5 border-none rounded-xl text-xs font-semibold px-4 py-2 focus:ring-0 appearance-none cursor-pointer hover:bg-black/10 transition-colors">
                        <option>10th Grade</option>
                        <option>12th Grade</option>
                        <option>Bachelor's</option>
                        <option>Master's</option>
                      </select>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <span className="text-[10px] uppercase tracking-widest text-black/30 font-bold px-2">Grades (%)</span>
                      <input 
                        type="text" 
                        placeholder="e.g. 85"
                        className="bg-black/5 border-none rounded-xl text-xs font-semibold px-4 py-2 focus:ring-0 w-24 hover:bg-black/10 transition-colors placeholder:text-black/20"
                      />
                    </div>

                    <div className="flex flex-col gap-1.5 grow">
                      <span className="text-[10px] uppercase tracking-widest text-black/30 font-bold px-2">Interests</span>
                      <input 
                        type="text" 
                        placeholder="Programming, Design, Music..."
                        className="w-full bg-black/5 border-none rounded-xl text-xs font-semibold px-4 py-2 focus:ring-0 hover:bg-black/10 transition-colors placeholder:text-black/20"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Suggestions */}
            <div className="flex flex-wrap justify-center gap-3">
              <SuggestionChip text="Strategize my career" />
              <SuggestionChip text="Learn about AI field" />
              <SuggestionChip text="Study abroad options" />
              <SuggestionChip text="Skill development" />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function SuggestionChip({ text }: { text: string }) {
  return (
    <button className="px-4 py-2 bg-white border border-black/5 rounded-xl text-xs font-medium text-black/50 hover:bg-black hover:text-white hover:border-black transition-all shadow-sm">
      {text}
    </button>
  );
}
